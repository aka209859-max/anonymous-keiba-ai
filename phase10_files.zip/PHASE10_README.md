# 🏇 Phase 10: 日次予測システム

## 📋 概要

Phase 10は、**Phase 8で最適化されたモデル**と**Phase 7で選択された特徴量**を使用して、当日の出走表データから予測を実行し、期待値ベースの購入推奨を生成する日次予測システムです。

## 🎯 Phase 10の位置付け

```
Phase 7: Boruta特徴量選択（完了済み）
    ↓ 29個の重要特徴量を選択
Phase 8: Optunaハイパーパラメータ最適化（完了済み）
    ↓ 14競馬場分の最適化モデルを生成
Phase 10: 日次予測システム ← ここ！
    ↓ Phase 8モデルで当日の予測を実行
Phase 6: 配信用テキスト生成
    ↓ note/Bookers/X用のテキスト生成
配信 🚀
```

## 📦 入力ファイル

Phase 10は以下のファイルを使用します:

### 1. Phase 8で生成された学習済みモデル
```
data/models/tuned/{venue}_tuned_model.txt
```
例: `data/models/tuned/monbetsu_tuned_model.txt`

### 2. Phase 7で選択された特徴量リスト
```
data/features/selected/{venue}_selected_features.csv
```
例: `data/features/selected/monbetsu_selected_features.csv`

### 3. 当日の出走表データ
```
Phase 0-4で生成されるデータ（run_all.batで取得）
```

## 📤 出力ファイル

Phase 10は以下のファイルを生成します:

### 1. 予測結果CSV
```
data/predictions/phase10/{venue}_{date}_predictions.csv
```
例: `data/predictions/phase10/ooi_20260211_predictions.csv`

### 2. 購入推奨CSV
```
data/predictions/phase10/{venue}_{date}_recommended_bets.csv
```
例: `data/predictions/phase10/ooi_20260211_recommended_bets.csv`

### 3. サマリーTXT
```
data/predictions/phase10/{venue}_{date}_summary.txt
```
例: `data/predictions/phase10/ooi_20260211_summary.txt`

## 🚀 使用方法

### 方法1: 単一競馬場の予測

```batch
RUN_PHASE10_DAILY.bat [競馬場コード] [日付]
```

**例: 2026年2月11日の大井競馬**
```batch
RUN_PHASE10_DAILY.bat 44 2026-02-11
```

**例: 2026年2月11日の佐賀競馬**
```batch
RUN_PHASE10_DAILY.bat 55 2026-02-11
```

### 方法2: 複数競馬場の一括予測

```batch
RUN_PHASE10_ALL_VENUES.bat [日付] [競馬場コード1] [競馬場コード2] ...
```

**例: 2026年2月11日の大井・川崎・佐賀**
```batch
RUN_PHASE10_ALL_VENUES.bat 2026-02-11 44 45 55
```

### 方法3: Python直接実行

```batch
python scripts\phase10_daily_prediction\run_daily_prediction.py --venue-code 44 --date 2026-02-11 --bankroll 100000 --kelly-fraction 0.25
```

## 📊 実行例

### 例1: 平日ナイター（大井・川崎）

```batch
cd E:\anonymous-keiba-ai

REM Phase 10: Phase 8モデルで予測
RUN_PHASE10_ALL_VENUES.bat 2026-02-11 44 45

REM Phase 6: 配信用テキスト生成
scripts\phase6_betting\BATCH_OPERATION.bat 2026-02-11

REM 確認
explorer predictions
```

### 例2: 土曜日複数開催（佐賀・大井・川崎・高知）

```batch
cd E:\anonymous-keiba-ai

REM Phase 10: Phase 8モデルで予測
RUN_PHASE10_ALL_VENUES.bat 2026-02-08 55 44 45 54

REM Phase 6: 配信用テキスト生成
scripts\phase6_betting\BATCH_OPERATION.bat 2026-02-08

REM 確認
explorer predictions
```

## 🔧 パラメータ説明

| パラメータ | 説明 | デフォルト値 |
|-----------|------|------------|
| `--venue-code` | 競馬場コード（例: 44） | 必須 |
| `--date` | 対象日（YYYY-MM-DD） | 必須 |
| `--bankroll` | 総資金（円） | 100,000 |
| `--kelly-fraction` | Kelly比率（1/4 Kelly推奨） | 0.25 |

## 📅 競馬場コード早見表

| コード | 競馬場 | 英語名 | コード | 競馬場 | 英語名 |
|--------|--------|--------|--------|--------|--------|
| 30 | 門別 | monbetsu | 35 | 盛岡 | morioka |
| 36 | 水沢 | mizusawa | 42 | 浦和 | urawa |
| 43 | 船橋 | funabashi | **44** | **大井** | **ooi** |
| **45** | **川崎** | **kawasaki** | 46 | 金沢 | kanazawa |
| 47 | 笠松 | kasamatsu | 48 | 名古屋 | nagoya |
| 50 | 園田 | sonoda | 51 | 姫路 | himeji |
| 54 | 高知 | kochi | **55** | **佐賀** | **saga** |

## 🔍 出力ファイルの確認方法

### 予測結果CSV
```batch
type data\predictions\phase10\ooi_20260211_predictions.csv
```

### 購入推奨CSV
```batch
type data\predictions\phase10\ooi_20260211_recommended_bets.csv
```

### サマリーTXT
```batch
notepad data\predictions\phase10\ooi_20260211_summary.txt
```

## 📈 期待される出力例

### サマリーTXT
```
============================================================
Phase 10: 日次予測サマリー
============================================================
競馬場: 大井 (ooi)
対象日: 2026-02-11
予測時刻: 2026-02-11 15:30:45

【予測統計】
  - 総レース数: 144件
  - 平均予測確率: 0.1234
  - 最大予測確率: 0.4567
  - 最小予測確率: 0.0123

【購入推奨】
  - 推奨馬数: 12頭
  - 総推奨金額: 15,000円
  - 平均期待値: 0.1523

【トップ5推奨馬】
  馬番 3: 確率0.456 EV+0.234 推奨2,500円
  馬番 7: 確率0.389 EV+0.198 推奨2,200円
  馬番 1: 確率0.345 EV+0.156 推奨1,800円
  馬番 5: 確率0.312 EV+0.134 推奨1,600円
  馬番 9: 確率0.289 EV+0.112 推奨1,400円

============================================================
Phase 10完了
============================================================
```

## 🔄 完全な日次運用フロー

### ステップ1: 出走表データ取得（Phase 0-4）
```batch
REM 必要な場合のみ実行（Phase 0-4が未実行の場合）
run_all.bat 44 2026-02-11
```

### ステップ2: Phase 10予測実行
```batch
RUN_PHASE10_DAILY.bat 44 2026-02-11
```

### ステップ3: Phase 6配信用テキスト生成
```batch
scripts\phase6_betting\DAILY_OPERATION.bat 44 2026-02-11
```

### ステップ4: 配信
```batch
REM predictions フォルダのテキストを確認
explorer predictions
notepad predictions\大井_20260211_note.txt
notepad predictions\大井_20260211_bookers.txt
```

## 🎯 ワンライナーコマンド（完全版）

### 大井競馬（2026-02-11）
```batch
cd E:\anonymous-keiba-ai && RUN_PHASE10_DAILY.bat 44 2026-02-11 && scripts\phase6_betting\DAILY_OPERATION.bat 44 2026-02-11 && notepad predictions\大井_20260211_note.txt
```

### 複数競馬場一括（2026-02-11）
```batch
cd E:\anonymous-keiba-ai && RUN_PHASE10_ALL_VENUES.bat 2026-02-11 44 45 55 && scripts\phase6_betting\BATCH_OPERATION.bat 2026-02-11 && explorer predictions
```

## ⚠️ 注意事項

### 1. Phase 8完了が必須
Phase 10を実行する前に、Phase 8（Optunaハイパーパラメータ最適化）が完了している必要があります。

**確認方法:**
```batch
dir data\models\tuned\*_tuned_model.txt
```

期待される結果: 14個の `*_tuned_model.txt` ファイルが存在

### 2. Phase 7完了が必須
Phase 7（Boruta特徴量選択）が完了している必要があります。

**確認方法:**
```batch
dir data\features\selected\*_selected_features.csv
```

期待される結果: 14個の `*_selected_features.csv` ファイルが存在

### 3. オッズ情報について
現在のバージョンでは、ダミーオッズを使用しています。実際の運用では、オッズAPIから最新オッズを取得する必要があります。

**今後の改善予定:**
- netkeiba APIとの連携
- リアルタイムオッズ取得
- オッズ変動の監視

## 🔧 トラブルシューティング

### エラー: モデルファイルが見つかりません
```
❌ モデルファイルが見つかりません: data/models/tuned/monbetsu_tuned_model.txt
```

**原因:** Phase 8が未完了

**解決策:**
```batch
REM Phase 8を実行
RUN_PHASE8_ALL_VENUES.bat
```

### エラー: 特徴量ファイルが見つかりません
```
❌ 特徴量ファイルが見つかりません: data/features/selected/monbetsu_selected_features.csv
```

**原因:** Phase 7が未完了

**解決策:**
Phase 7は既に完了済みのはずです。ファイルの存在を確認してください。

### エラー: レースデータが見つかりません
```
❌ レースデータが見つかりません: 44 2026-02-11
```

**原因:** Phase 0-4が未実行

**解決策:**
```batch
REM Phase 0-4を実行
run_all.bat 44 2026-02-11
```

## 💡 Pro Tips

### Tip 1: 毎日自動実行
タスクスケジューラで毎朝自動実行を設定できます。

### Tip 2: 複数ウィンドウで並行処理
```batch
start cmd /k "cd E:\anonymous-keiba-ai && RUN_PHASE10_DAILY.bat 44 2026-02-11"
start cmd /k "cd E:\anonymous-keiba-ai && RUN_PHASE10_DAILY.bat 45 2026-02-11"
```

### Tip 3: ログ出力
```batch
RUN_PHASE10_DAILY.bat 44 2026-02-11 > logs\phase10_20260211.log 2>&1
```

## 🎉 Phase 10完了後の配信準備

Phase 10完了後、以下のファイルが配信可能になります:

1. **note/Bookers/X用テキスト** (Phase 6で生成)
   - `predictions/{競馬場}_{日付}_note.txt`
   - `predictions/{競馬場}_{日付}_bookers.txt`

2. **購入推奨リスト** (Phase 10で生成)
   - `data/predictions/phase10/{競馬場}_{日付}_recommended_bets.csv`

3. **サマリー** (Phase 10で生成)
   - `data/predictions/phase10/{競馬場}_{日付}_summary.txt`

---

**Phase 10で毎日の予測、頑張ってください！** 🏇✨
